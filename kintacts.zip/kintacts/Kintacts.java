package com.pushkin;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

public class Kintacts extends AppCompatActivity  {

    private CustomAdapter<String> mAdapter;
    private ArrayList<String> data=new ArrayList<String>();
    private ListView listView;
    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_scrolling);

        updateAdapter();

        editText=(EditText)findViewById(R.id.editText);

        editText.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                // When user changed the Text
                Kintacts.this.mAdapter.getFilter().filter(cs);
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {}

            @Override
            public void afterTextChanged(Editable arg0) {}
        });
    }

    public void updateAdapter(){
        //Read the file with our data
        String kintactNames= "Francis Choi;francischoi97\nNoah Orlando;manwhoami\nSean Fitzgerald;sfitz97\nHarith Aslam;hkhwaja\nAarathi Prasad;aprasad\nDiego Ramos-Meyer;nurbodiego\nBob;boringbob\nGary;garysnail\nShreeansh Agarwal;freemeshree\nAlex Pushkin;daRussianpoet\nRobert Frost;tworoadsdiverged\nEmily Dickinson;idkherpoems";

        //Create the arrayList of that data
        String[] lines = kintactNames.split("\\n");
        for (String i:lines){
            data.add(i);
        }
        Collections.sort(data.subList(0, data.size()));

        //Create the adapter with this new info
        mAdapter = new CustomAdapter<String>(this, R.layout.activity_contacts_listview, R.id.contactsList, data);
        listView = (ListView)findViewById(R.id.contactsList);
        listView.setAdapter(mAdapter);
        listView.setSmoothScrollbarEnabled(true);
        listView.setTextFilterEnabled(true);
        //listView.setFriction(ViewConfiguration.getScrollFriction() * (float)2);

        //Set the view of this adapter to the bottom
        listView.setSelection(listView.getCount() - 1);
    }

    private class CustomAdapter<E> extends ArrayAdapter<String> {

        public CustomAdapter(Context context, int resource, int id, ArrayList<String> data) {
            super(context, resource, id, data);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the data item for this position
            String s = getItem(position);
            System.out.println("The thing is [" + s + "]");

            System.out.println("Inflating view to [to]");
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_contacts_listview, parent, false);

            TextView nickname = (TextView) convertView.findViewById(R.id.nickname);
            TextView username = (TextView) convertView.findViewById(R.id.username);
            // Populate the data into the template view using the data object
            nickname.setText(s.split(";")[0]);
            nickname.setTextColor(Color.BLACK);

            username.setText(s.split(";")[1]);

            // Return the completed view to render on screen
            return convertView;
        }
    }
}
