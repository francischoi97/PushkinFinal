package com.pushkin;

import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Base64;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import android.view.ViewGroup;
import android.widget.TextView;

import com.pushkin.activity.MainActivity;
import com.pushkin.fragment.ConversationsFragment;
import com.pushkin.other.MessageView;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class Chat extends AppCompatActivity {

    CustomAdapter<MessageView> mAdapter;
    ArrayList<String> data;
    EditText editText;
    Message m;
    private String[] activityTitles;
    public static int navItemIndex = 0;

    public static PushkinDatabaseHelper dbHelper;
    int chatID;
    private Toolbar toolbar;

    private ListView listView;


    public void updateAdapter(){
        //get Messages
        ArrayList<MessageView> messages = dbHelper.getMessages(chatID);
        //Create the adapter with this new info
        mAdapter = new CustomAdapter<MessageView>(this, R.layout.activity_listview, R.id.listview, messages);
        listView = (ListView)findViewById(R.id.listview);
        listView.setDivider(null);
        listView.setDividerHeight(0);
        listView.setAdapter(mAdapter);
        //listView.smoothScrollToPosition(listView.getCount() - 1);

        //Set the view of this adapter to the bottom
        listView.setSelection(listView.getCount() - 1);
    }
    private void setToolbarTitle(String chatName) {
        getSupportActionBar().setTitle(chatName);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        dbHelper = MainActivity.dbHelper;
        chatID = getIntent().getIntExtra("CHAT_ID",0);
        String firstName = dbHelper.getFirstName(chatID);
        String lastName = dbHelper.getLastName(chatID);

        activityTitles = getResources().getStringArray(R.array.nav_item_activity_titles);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setToolbarTitle(firstName + " " + lastName);
        if (getSupportActionBar() != null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        //System.out.println (chatID);
        //System.out.println("if chatID is 0, then error!!");
//        System.out.println("here");
//        Intent intent = new Intent(this, MainConversationView.class);
//        startActivity(intent);

        final Handler handler=new Handler();
        handler.post(new Runnable(){
            @Override
            public void run() {
                //update textView here
                updateAdapter(); //there should be no need for this update adpater right?
                handler.postDelayed(this,500); // set time here to refresh textView
            }
        });

        //
        editText = (EditText)findViewById(R.id.messagebox);
//
        final Button sendButton = (Button)findViewById(R.id.sendbutton);
        sendButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //hide the keyboard
//                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
//                imm.hideSoftInputFromWindow(sendButton.getWindowToken(), InputMethodManager.RESULT_UNCHANGED_SHOWN);
                sendMessage();

            }
        });

    }

    private class CustomAdapter<E> extends ArrayAdapter<MessageView> {

        public CustomAdapter(Context context, int resource, int id, ArrayList<MessageView> data) {
            super(context, resource, id, data);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the data item for this position
            MessageView s = getItem(position);

            String sender = s.getSender();
            String text = s.getText();
            String time = s.getTime();
            String firstName = dbHelper.getFirstName(chatID);
            String lastName = dbHelper.getFirstName(chatID);

            if(!sender.equals(getLocalUser()))
            {
                //System.out.println("Inflating view to [to]");
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_listview, parent, false);

                // Lookup view for data population
                TextView username = (TextView) convertView.findViewById(R.id.username);
                TextView textMessage = (TextView) convertView.findViewById(R.id.textmessage);
                TextView timeStamp = (TextView) convertView.findViewById(R.id.timestamp);
                // Populate the data into the template view using the data object
                username.setText(firstName);
                textMessage.setText(text);
                timeStamp.setText(time);

                username.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 17);
                username.setTypeface(null, Typeface.BOLD);
                textMessage.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15);

                timeStamp.setTextSize(11);
            }
            else{
                //from
                //System.out.println("Inflating view to [from]");
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_listview_from, parent, false);
                convertView.setBackgroundColor(Color.parseColor("#B3E5FC"));
                convertView.getBackground().setAlpha(116);
                // Lookup view for data population

                TextView username = (TextView) convertView.findViewById(R.id.username);
                TextView textMessage = (TextView) convertView.findViewById(R.id.textmessage);
                TextView timeStamp = (TextView) convertView.findViewById(R.id.timestamp);
                // Populate the data into the template view using the data object
                username.setText("Me");
                textMessage.setText(text);
                timeStamp.setText(time);


                username.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 17);
                username.setTypeface(null, Typeface.BOLD);

                textMessage.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 15);

                timeStamp.setTextSize(11);


            }
            // Return the completed view to render on screen
            return convertView;
        }
    }

    public String getTime() {
        Calendar cal = Calendar.getInstance();
        Date currentDate = new Date();
        cal.setTime(currentDate);
        //cal.add(Calendar.SECOND, -30080);
        SimpleDateFormat sdf = new SimpleDateFormat("0h:m a");
        return sdf.format(cal.getTime());
    }

    public void sendMessage() {

        String message = editText.getText().toString();
        String sender = getLocalUser();
        String time = getTime();
        m = new Message(sender,time,message);

        editText.setText("");

        sendtoServer(m);

    }

    public void sendtoServer(Message message) {
        new PushkinAsyncTask().execute(message);
    }

    public String readUserTokenFile(){
        String authorizationToken = "";
        try {
            FileInputStream fIn;
            fIn = openFileInput("userToken.dat");
            int n;
            while((n = fIn.read()) != -1) {
                authorizationToken = authorizationToken + Character.toString((char)n);

            }
            fIn.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        //return authorizationToken
        return authorizationToken;
    }

    public String getLocalUser(){
        String token = readUserTokenFile();
        return token.split(":")[0];
    }

    public String getLocalAuthToken(){
        String token = readUserTokenFile();
        return token.split(":")[1];
    }

    public class PushkinAsyncTask extends AsyncTask<Message, Void, Boolean> {

        @Override
        protected Boolean doInBackground(Message... params) {
            String localUser = getLocalUser();
            String token = getLocalAuthToken();
            Message m = params[0];
            String message = params[0].getText();

            String recipient = dbHelper.getConversant(chatID);


            //encode the Base64.encodeBase64 expects byte[]. eMsg is a byte[] that contains the encrypted message

            byte[] b64Msg = Base64.encode(message.getBytes(), Base64.NO_WRAP);
            HttpURLConnection harpoon;
            String url = "http://148.85.240.18:8080/sendMsg";
            String result = null;
            String thing = "{\"recipient\":\"" + recipient + "\",\"message\":\"" + new String (b64Msg) + "\",\"authorization\":\"" + getLocalUser() + ":" + getLocalAuthToken() + "\"}";

            try {
                //Connect
                harpoon = (HttpURLConnection) ((new URL(url).openConnection()));
                harpoon.setDoOutput(true);
                harpoon.setRequestProperty("Content-Type", "application/json");
                harpoon.setRequestProperty("Accept", "application/json");
                harpoon.setRequestMethod("POST");
                harpoon.connect();

                //Write
                OutputStream os = harpoon.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(thing);
                writer.close();
                os.close();

                //Read
                BufferedReader br = new BufferedReader(new InputStreamReader(harpoon.getInputStream(), "UTF-8"));

                String line = null;
                StringBuilder sb = new StringBuilder();

                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }

                br.close();
                result = sb.toString();
                JSONObject json = new JSONObject(result);
                String success = json.getString("Success");
                if (success.equals("0")) {
                    //we have failed to login, throw bad login.
                    //System.out.println(result);
                    //System.out.println(success);
                    return false;
                }
                //else, we are good, get token and store it...
                String response = json.getString("Message");
                //System.out.println(response);
                return true;

            } catch (IOException e) {
                e.printStackTrace();
                return false;
            } catch (JSONException e) {
                e.printStackTrace();
                return false;
            }
        }
        private View.OnClickListener whatIsThat = new View.OnClickListener() {
            public void onClick(View v) {
                System.out.println("buttonWasClicked");
            }
        };
        @Override
        protected void onPostExecute(Boolean result) {
            super.onPostExecute(result);

            if (result) {
                dbHelper.addSentMessage(m, chatID);
                updateAdapter();
            }
            else{
                Snackbar.make(findViewById(android.R.id.content), "Sorry, we couldn't send that message.", Snackbar.LENGTH_LONG)
                        //.setAction("Retry", whatIsThat)
                        //.setActionTextColor(Color.RED)
                        .show();
            }
        }
    }
}
